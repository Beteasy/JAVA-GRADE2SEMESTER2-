package shang_zhuan;

public class Anthropoid {
	double m = 12.58;
	void crySpeak(String s) {
		System.out.println( s);
	}
}
