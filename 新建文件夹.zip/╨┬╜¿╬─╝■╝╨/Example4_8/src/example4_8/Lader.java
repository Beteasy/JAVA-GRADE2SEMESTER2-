package example4_8;

public class Lader {
	double upLader;	//ʵ������
	double height;	//�����
	static double downLader;
	void setUpLaderr(double a) {
		upLader = a;
	}
	
	void setDownLader(double b) {
		downLader = b;
	}

	double getUpLader() {
		return upLader;
	}
	
	double getDownLader() {
		return downLader;
	}
}
