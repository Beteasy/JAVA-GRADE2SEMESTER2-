package toCharArray;

public class ToCharArray {
	public static void main(String[] argv) {
		String str = "I am a Chinese. And I love China!";
		char chArray[] = str.toCharArray();
		System.out.println(chArray);
	}

}
