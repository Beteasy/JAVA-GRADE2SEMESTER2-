/**
 * 
 */
/**
 * @author John
 *
 */
module enum_for_switch {
}