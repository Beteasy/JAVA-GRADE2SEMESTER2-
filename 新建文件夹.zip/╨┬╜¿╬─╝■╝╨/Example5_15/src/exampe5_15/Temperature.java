package exampe5_15;

public interface Temperature {
	public void controlTemperature();
}
