package exampe5_15;

public interface Charge {
	public void charge();
}
