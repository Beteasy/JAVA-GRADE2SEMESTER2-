package exampe5_15;

public class Example5_15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bus seventh = new Bus();
		Taxi taxi  = new Taxi();
		Teater teater = new Teater();
		seventh.charge();
		taxi.charge();
		teater.charge();
	}

}
