package length;

public class Class {
	public static void main(String[] argv) {
		String str = "HELLO WORLD �й�!";
		String str2 = "";
		System.out.println(str.length());
		System.out.println(str2.length());
	}

}
