package shiyan4;

abstract class Geometry {
	public abstract double getArea();
}
