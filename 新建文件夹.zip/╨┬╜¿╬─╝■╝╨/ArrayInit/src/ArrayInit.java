
public class ArrayInit {
	static int Array[] = new int[] {1,2};
	//static int Array[] = {1,2};
	public static void main(String[] argv) {
		System.out.println(Array[0]);
		System.out.println(Array[1]);
	}
}
