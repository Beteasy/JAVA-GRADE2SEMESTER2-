/**
 * 
 */
/**
 * @author John
 *
 */
module Rational {
}