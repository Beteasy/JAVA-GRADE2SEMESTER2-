package example5_14;

public interface Computable {
	public final int MAX = 100;
	public abstract int f(int x);
}
