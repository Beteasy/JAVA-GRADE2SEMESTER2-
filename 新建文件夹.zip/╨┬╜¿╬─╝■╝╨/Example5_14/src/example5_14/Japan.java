package example5_14;

public class Japan implements Computable{
	int number;
	public int f(int x) {
		return 66+x;
	}
}
