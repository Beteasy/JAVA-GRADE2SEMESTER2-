package example_5_16;

public interface showMessage {
	public abstract void showmessage(String s);
}
