package example_5_16;

public class PC implements showMessage {

	@Override
	public void showmessage(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
	}

}
