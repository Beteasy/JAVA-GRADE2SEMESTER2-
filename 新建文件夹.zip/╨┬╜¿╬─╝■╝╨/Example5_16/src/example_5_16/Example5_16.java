package example_5_16;

public class Example5_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		showMessage sm;
		sm = new TV();
		sm.showmessage("�������");
		
		sm = new PC();
		sm.showmessage("��˶");
	}

}
