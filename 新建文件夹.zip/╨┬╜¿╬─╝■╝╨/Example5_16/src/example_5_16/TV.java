package example_5_16;

public class TV implements showMessage {

	@Override
	public void showmessage(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
		}
}
