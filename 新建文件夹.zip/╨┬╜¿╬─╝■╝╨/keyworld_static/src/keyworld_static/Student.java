package keyworld_static;

public class Student {
	public static String S = "abc";
	public String no;
	public String name;
	public int age;
	
	public void study() {}
	
	public static void f1() {
		System.out.println("f1");
	}

}
