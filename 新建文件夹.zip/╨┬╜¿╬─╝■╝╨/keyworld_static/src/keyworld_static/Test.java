package keyworld_static;

public class Test {
	public static void main(String[] args) {
		String result = Student.S;
		
		
	}

}
