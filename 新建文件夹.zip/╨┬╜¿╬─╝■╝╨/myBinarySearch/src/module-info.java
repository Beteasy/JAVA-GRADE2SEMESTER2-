/**
 * 
 */
/**
 * @author John
 *
 */
module myBinarySearch {
}