package myBinarySearch;
import java.util.Scanner;

public class MyBinarySearch {

	public static void main(String[] args) {
		int array[] = {5,7,9,12,15,17,20,22,26,27};
		int low = 0;
		int heigh = array.length;
		int mid = (low+heigh)/2;
		Scanner num = new Scanner(System.in);
		while(low<heigh)
		{
			
		}
	}

}
