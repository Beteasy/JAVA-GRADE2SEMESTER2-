package equals;

public class Equals {
	public static void main(String[] argv) {
		int intArray[] = new int[] {10,20,30,40,50,60,70};
		
	}

}
