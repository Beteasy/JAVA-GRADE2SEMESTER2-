package sum;

public class Sum {
	public static void main(String args[]) {
		double d = getSum(1,2);
		System.out.println(d);
	}
	
	public static double getSum(double a, double b) {
		return a+b;
	}
}

