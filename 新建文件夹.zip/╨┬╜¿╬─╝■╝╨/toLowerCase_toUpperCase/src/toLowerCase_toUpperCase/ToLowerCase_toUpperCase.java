package toLowerCase_toUpperCase;

public class ToLowerCase_toUpperCase {
	public static void main(String[] argv) {
		String str = "This Is A String";
		System.out.println(str.toLowerCase());
		System.out.println(str.toUpperCase());
	}

}
