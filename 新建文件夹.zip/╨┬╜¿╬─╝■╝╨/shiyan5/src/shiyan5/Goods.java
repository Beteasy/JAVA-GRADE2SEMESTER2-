package shiyan5;

public class Goods {
	private String name;
	private boolean isDanger;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setIsDanger(boolean isDanger) {
		this.isDanger = isDanger;
	}
	
	public boolean getIsDanger() {
		return isDanger;
	}
}
