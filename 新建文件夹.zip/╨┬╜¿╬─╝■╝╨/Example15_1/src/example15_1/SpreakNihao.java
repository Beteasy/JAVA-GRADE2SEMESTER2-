package example15_1;

public class SpreakNihao {
	public void run() {
		
	}
}
