
public class Trim {
	public static void main(String[] argv) {
		String str = "   hellow world    ";
		String str2 = "hellow world";
		String str3 = "         ";
		System.out.println("\""+str.trim()+"\"");
		System.out.println("\""+str2.trim()+"\"");
		System.out.println("\""+str3.trim()+"\"");
	}

}
