package xiti2_2;

public class Xiti2_2 {
	public static void main(String[] args) {
		//int x = 12L;
		Long x = 12L;
		//long y = 8.0;
		double y = 8.0;
		float y = 6.89F;
		System.out.println(y);
	}

}
