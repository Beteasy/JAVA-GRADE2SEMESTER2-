/**
 * 
 */
/**
 * @author John
 *
 */
module rectangle {
}