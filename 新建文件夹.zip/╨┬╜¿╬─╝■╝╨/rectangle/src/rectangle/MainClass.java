package rectangle;

public class MainClass {
	public static void main(String args[]) {
		Circle circle = new Circle();
		circle.printArea(100);
		Rectangle rect = new Rectangle();
		rect.printArea(100, 65);
	}

}
