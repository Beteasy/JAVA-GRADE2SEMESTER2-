package rectangle;

public class Circle {
	void printArea(double r) {
		System.out .println(r*r*3.1416926);
	}

}
