package rectangle;

public class Rectangle {
		void printArea(double a, double b) {
			System.out .println(a*b);
		}

}
