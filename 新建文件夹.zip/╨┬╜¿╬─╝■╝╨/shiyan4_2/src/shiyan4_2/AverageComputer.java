package shiyan4_2;

public interface AverageComputer {
	public abstract double average(double[] x);
}
