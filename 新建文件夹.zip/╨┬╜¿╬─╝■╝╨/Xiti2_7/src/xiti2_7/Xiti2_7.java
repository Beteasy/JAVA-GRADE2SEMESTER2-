package xiti2_7;

public class Xiti2_7 {

	public static void main(String[] args) {
		char ch[] = {'��','��','��'};
		for(int i = 0; i<ch.length; i++)
		{
			System.out.println((int)ch[i]);
		}
		

	}

}
