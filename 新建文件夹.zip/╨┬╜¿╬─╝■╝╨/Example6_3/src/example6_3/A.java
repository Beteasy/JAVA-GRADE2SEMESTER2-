package example6_3;

public class A {
	void f(Cubic cubic) {
		double result = cubic.getCubic(3);
		System.out.println("result=" + result);
	}
}
