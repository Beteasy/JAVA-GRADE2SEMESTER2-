package example6_3;

public interface Cubic {
	public abstract double getCubic(double x);

}
