package example5_10;

public class Animal {
	void cry() {
		
	}
}
