package zuoyi;

public class ZuoYi {
	public static void main(String args[]) {
		int a = 4;		//0000 0100
		int b = a << 1;	
		System.out.println(b);
	}

}
