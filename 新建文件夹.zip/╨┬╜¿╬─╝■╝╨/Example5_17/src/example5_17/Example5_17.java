package example5_17;

public class Example5_17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdvertisementBoard board = new AdvertisementBoard();
		board.show(new Philips());
		board.show(new Lenovo());
	}

}
