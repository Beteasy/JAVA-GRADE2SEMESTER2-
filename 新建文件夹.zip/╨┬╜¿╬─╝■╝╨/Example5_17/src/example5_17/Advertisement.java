package example5_17;

public interface Advertisement {
	public abstract void showAdvertisement();
	public abstract String showCorpName();
}
