package example5_17;

public class Lenovo implements Advertisement{		//Lenovoʵ��Advertisements�ӿ�
	
	public void showAdvertisement() {
		System.out.println("**************");
		System.out.println("�������ú�С");
		System.out.println("**************");
	}
	
	public String showCorpName() {
		return "����";
	}
}
