package example5_17;

public class Philips implements Advertisement {		//Philipsʵ��Advertisement�ӿ�

	@Override
	public void showAdvertisement() {
		// TODO Auto-generated method stub
		System.out.println("@@@@@@@@@@@@@@@@@@");
		System.out.println("û����ã�ֻ�и���");
		System.out.println("@@@@@@@@@@@@@@@@@@");
	}

	@Override
	public String showCorpName() {
		// TODO Auto-generated method stub
		return "������";
	}

}
