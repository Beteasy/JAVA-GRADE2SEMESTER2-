/**
 * 
 */
/**
 * @author John
 *
 */
module anwei_and_or_not {
}