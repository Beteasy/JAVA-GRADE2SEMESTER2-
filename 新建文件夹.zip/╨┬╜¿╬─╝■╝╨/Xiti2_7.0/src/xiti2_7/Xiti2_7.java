package xiti2_7;

public class Xiti2_7 {

	public static void main(String[] args) {
		char ch = 65;
		System.out.printf("%c,%d\n",ch,(int)ch);
		byte by = (byte)129;
		System.out.println(by);
		double d = 123456.783124;
		System.out.printf("%12.3f,%12.5f",d,d);

	}

}
