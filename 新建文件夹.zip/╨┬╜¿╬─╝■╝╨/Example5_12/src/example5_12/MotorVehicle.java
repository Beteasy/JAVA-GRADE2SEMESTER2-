package example5_12;

abstract public class MotorVehicle {
	abstract void start();
	abstract void accelerate();
	abstract void brake();
}
