package example5_12;

public class Example5_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ManualVehicle car1 = new ManualVehicle();
		car1.start();
		car1.accelerate();
		car1.brake();
	}

}
