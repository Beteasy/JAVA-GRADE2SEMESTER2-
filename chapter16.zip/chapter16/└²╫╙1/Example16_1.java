public class Example16_1 {

   public static void main(String args[]) {
      WindowURL win=new WindowURL();
      win.setTitle("��ȡURL�е���Դ");
   }
}

