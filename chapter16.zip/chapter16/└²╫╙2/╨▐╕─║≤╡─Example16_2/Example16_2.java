package chapter16.Example16_2;

public class Example16_2 {
   public static void main(String args[]) {
      WindowHTML win=new WindowHTML();
      win.setTitle("��ʾ��ҳ");
   }
}

