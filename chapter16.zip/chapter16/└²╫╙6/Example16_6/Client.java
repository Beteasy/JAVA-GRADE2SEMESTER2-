package chapter16.Example16_6;

import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

public class Client {
   public static void main(String args[]) {
     new WindowClient();
   }
}

