public abstract class Animal{
    public abstract void cry();
    public abstract String getAnimalName();
}
