public class Cat extends Animal {
   public void cry() {
      System.out.println("����...����"); 
   }  
   public String getAnimalName() {
      return "è";
   }
}
