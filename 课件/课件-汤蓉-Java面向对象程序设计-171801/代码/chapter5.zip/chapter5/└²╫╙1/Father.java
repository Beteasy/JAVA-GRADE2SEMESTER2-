public class Father { 
    private int money;
    int weight;
    int getWeight() { 
       return weight ;
    }
    protected void setWeight(int w) {
       weight=w;
    }    
}
