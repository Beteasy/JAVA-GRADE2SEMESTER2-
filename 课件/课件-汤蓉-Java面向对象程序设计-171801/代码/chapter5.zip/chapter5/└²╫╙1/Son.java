public class Son extends Father { 
    String hand;
    public void setHand(String hand) {
        this.hand=hand;
    }
    String getHand() {
        return hand;
    } 
} 
