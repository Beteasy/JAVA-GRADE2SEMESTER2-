public interface Advertisement {
      public void showAdvertisement();
      public String getCorpName();
}
