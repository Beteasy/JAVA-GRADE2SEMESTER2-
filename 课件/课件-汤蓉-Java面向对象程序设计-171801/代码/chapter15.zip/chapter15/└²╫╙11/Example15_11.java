public class Example15_11 {
   public static void main(String args[]) {
      WindowTicket win=new WindowTicket();
      win.setTitle("���Ŷ���Ʊ");
   }
}
