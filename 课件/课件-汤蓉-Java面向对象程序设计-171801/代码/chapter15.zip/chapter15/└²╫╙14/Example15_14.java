public class Example15_14 {
   public static void main(String args[]) {
     ThreadJoin  a=new ThreadJoin();
     a.customer.start();
   }
}
