public class Example15_7 {
   public static void main(String args[]) {
      ClassRoom room=new ClassRoom();
      room.student.start();
      room.teacher.start();

   }
}
