public class Example15_9 {
   public static void main(String args[]) {
      Win win=new Win();
   }
}
