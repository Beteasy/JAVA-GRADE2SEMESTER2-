public class Example15_13 {
   public static void main(String args[]) {
      WindowTime win=new WindowTime();
      win.setTitle("��ʱ��");
   }
}
