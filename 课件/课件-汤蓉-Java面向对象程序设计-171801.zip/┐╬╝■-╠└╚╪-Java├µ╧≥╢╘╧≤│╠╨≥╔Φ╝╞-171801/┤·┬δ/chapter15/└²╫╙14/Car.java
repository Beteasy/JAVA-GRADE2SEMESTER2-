public class Car {
   float price;
   String name;
   Car(String name,float price) {
      this.name=name;
      this.price=price;
   }
}
