public class A {
 public void hello() {
       System.out.println("���");
   } 
}
