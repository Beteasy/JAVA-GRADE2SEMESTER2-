public class Example12_15 {
   public static void main(String args[]) {
      WindowClone win=new WindowClone();
      win.setTitle("�õ��ı����Ŀ�¡");
   }
}

