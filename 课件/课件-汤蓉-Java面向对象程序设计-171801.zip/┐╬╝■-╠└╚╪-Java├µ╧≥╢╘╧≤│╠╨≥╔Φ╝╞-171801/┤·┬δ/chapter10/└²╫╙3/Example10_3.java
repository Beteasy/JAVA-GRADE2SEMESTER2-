public class E {
   public static void main(String args[]) {
      ComponentInWindow win = new ComponentInWindow();
      win.setBounds(100,100,300,260);
      win.setTitle("�������"); 
   }
}
