public class Example6_1 {
   public static void main(String args[]) {
      RedCowForm form = new RedCowForm("��ţũ��");
      form.showCowMess();
      form.cow.speak();
   }   
}


