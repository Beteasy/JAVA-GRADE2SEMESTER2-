public interface Com {
     public abstract int sub(int x,int y);
}

