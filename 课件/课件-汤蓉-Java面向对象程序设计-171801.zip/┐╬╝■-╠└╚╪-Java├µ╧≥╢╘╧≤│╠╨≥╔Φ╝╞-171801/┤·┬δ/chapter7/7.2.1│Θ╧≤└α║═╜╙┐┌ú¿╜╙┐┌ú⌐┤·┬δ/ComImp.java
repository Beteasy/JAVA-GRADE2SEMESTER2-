class ComImp implements Com {
     public  int sub(int x,int y) {
         return x-y;
    }
}


