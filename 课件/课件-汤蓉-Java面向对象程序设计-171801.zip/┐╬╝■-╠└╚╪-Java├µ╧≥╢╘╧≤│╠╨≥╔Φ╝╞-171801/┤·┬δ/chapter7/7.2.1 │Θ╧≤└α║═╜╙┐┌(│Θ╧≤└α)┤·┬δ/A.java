public abstract class A {
     public abstract int add(int x,int y);
}
