public class B extends A {
     public  int add(int x,int y) {
         return x+y;
    }
}

