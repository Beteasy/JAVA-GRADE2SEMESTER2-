public class Computer {
   Com com;
   public void setCom(Com com){
      this.com=com;
   }
   public void f(){
      com.compuer();
   }
}

