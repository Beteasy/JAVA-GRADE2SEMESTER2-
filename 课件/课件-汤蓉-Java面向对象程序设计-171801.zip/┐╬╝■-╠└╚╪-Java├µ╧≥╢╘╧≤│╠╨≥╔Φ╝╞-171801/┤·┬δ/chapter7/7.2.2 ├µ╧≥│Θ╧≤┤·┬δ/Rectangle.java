public class Rectangle extends Geometry {
    double a,b;
    Lader(double a,double b) {
        this.a=a; this.b=b; 
    }
    public double getArea() {
        return a*b;
    }
}





