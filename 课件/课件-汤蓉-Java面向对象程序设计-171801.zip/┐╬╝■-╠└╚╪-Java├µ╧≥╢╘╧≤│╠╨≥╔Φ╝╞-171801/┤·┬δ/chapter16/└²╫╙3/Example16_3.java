public class Example16_3 {
   public static void main(String args[]) {
      WindowLink win=new WindowLink();
   }
}

