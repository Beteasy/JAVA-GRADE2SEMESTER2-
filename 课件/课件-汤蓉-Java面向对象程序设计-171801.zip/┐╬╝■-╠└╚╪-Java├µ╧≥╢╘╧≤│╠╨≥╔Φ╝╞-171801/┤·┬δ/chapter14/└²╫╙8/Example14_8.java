import java.sql.*;
import java.util.*;
public class Example14_8 {
   public static void main(String args[]) {
     ModifyTable modify=new ModifyTable();
     modify.setDatasourceName("moon");
     modify.setSQL("UPDATE message SET Ʒ�� = '�������' WHERE ����='c324'");
     String backMess=modify.modifyRecord();
     System.out.println(backMess); 
     Query query=new SequenceQuery();
     query.setDatasourceName("moon");
     query.setTableName("message");
     ArrayList<StringBuffer> result=query.getQueryResult();
     for(StringBuffer str:result) {
        System.out.println(str);  
     }
   } 
}
