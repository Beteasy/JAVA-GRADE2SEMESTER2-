public class Example5_17 {
   public static void main(String args[]) {
      AdvertisementBoard board = new AdvertisementBoard();
      board.show(new PhilipsCorp());
      board.show(new LenovoCorp());
   }
}
