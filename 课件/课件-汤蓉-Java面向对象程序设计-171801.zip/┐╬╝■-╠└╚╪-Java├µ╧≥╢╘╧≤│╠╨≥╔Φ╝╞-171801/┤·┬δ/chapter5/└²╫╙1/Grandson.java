public class Grandson extends Son {
    String foot ;
    public void setFoot(String foot) {
       this.foot=foot;
    }
    String getFoot() {
       return foot;
    } 
}
