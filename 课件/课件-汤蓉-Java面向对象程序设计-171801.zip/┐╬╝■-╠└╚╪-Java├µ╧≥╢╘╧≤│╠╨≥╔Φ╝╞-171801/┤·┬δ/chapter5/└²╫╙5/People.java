public class People {
    public void speak(){
       System.out.println("����People");
    }
}


