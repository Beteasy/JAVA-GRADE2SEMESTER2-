package ʵ��4;

public abstract class Geometry {
	public abstract double getArea();
}
