package ʵ��5;

public class Goods {
	private String name;
	private boolean isDanger;	   

	public boolean isDanger() {
		return isDanger;
	}

	public void setDanger(boolean isDanger) {
		this.isDanger = isDanger;
	}    
	   
	public void setName(String s) {
		name = s;
	}
	   
	public String getName() {
		return name;
	}
}
